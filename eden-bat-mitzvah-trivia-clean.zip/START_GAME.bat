@echo off
chcp 65001 > nul
echo ===================================================
echo   🎉 משחק טריוויית בת המצווה של עדן 👑✨
echo ===================================================
echo.
echo מפעיל את השרת...
start http://localhost:3000/host.html
node server.js
pause
